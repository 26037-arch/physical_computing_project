// V3: fixed core axle, hollow F/B belt drives, opposite-face locks.
// Meshes use CAD assembly coordinates from export_sim_v3.py (not print poses).
// The open outer frame is a display variant; motion is an explanatory preview.
(function () {
  'use strict';
  const C = CubeLib, S = CubeSolver;
  const MODELS = (typeof CubeModels !== 'undefined') ? CubeModels : { params: {}, parts: {} };
  // V3 CAD dimensions and assembly-coordinate meshes.
  const P = Object.assign({ cube_mm: 57, piece_mm: 18.8, pitch_mm: 19.1, retract_mm: 24, pin_mm: 3, socket_mm: 3.4,
    socket_depth_mm: 4.2, pin_engagement_mm: 3, plate_thickness_mm: 6 }, MODELS.params || {});
  const UNIT = P.pitch_mm;                 // 1 단위 = 조각 중심 간격 = 19.1 mm
  const mm = (x) => x / UNIT;
  const HALF = mm(P.cube_mm / 2);          // 큐브 중심 → 면 거리 (28.5 mm): 헤드 배치용
  const SURF = mm(P.piece_mm / 2);         // 큐비 중심 → 그 면 거리 (9.4 mm): 스티커·소켓은 큐비(피치 위치)의 자식이므로 이 값을 쓴다
  const SCRAMBLE_LEN = 20;
  // 보드 속도 추정 근거: Wokwi(Uno, 16 MHz AVR) 시드 1 측정 — CALC nodes=108161 ms=4733 (Codex 최적화 후, 최적화 전 15613)
  const AVR_NODES_PER_SEC = 108161 / 4.733;
  const FACE_NAMES = ['U', 'R', 'F', 'D', 'L', 'B'];
  const AXIS_NAMES = ['U/D', 'R/L', 'F/B'];

  // ---------- 3D 장면 ----------
  const canvas = document.getElementById('view');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0f1216);
  const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 400);
  scene.add(new THREE.HemisphereLight(0xffffff, 0x334455, 0.85));
  const key = new THREE.DirectionalLight(0xffffff, 0.8); key.position.set(6, 9, 7); scene.add(key);
  const fill = new THREE.DirectionalLight(0xffffff, 0.4); fill.position.set(-7, -4, -6); scene.add(fill);

  // 면 순서 U R F D L B. 바깥 법선, 그 면을 정면에서 볼 때 스티커 격자의 오른쪽/아래 방향
  const N = [[0, 1, 0], [1, 0, 0], [0, 0, 1], [0, -1, 0], [-1, 0, 0], [0, 0, -1]];
  const RIGHT = [[1, 0, 0], [0, 0, -1], [1, 0, 0], [1, 0, 0], [0, 0, 1], [-1, 0, 0]];
  const DOWN = [[0, 0, 1], [0, -1, 0], [0, -1, 0], [0, 0, -1], [0, -1, 0], [0, -1, 0]];
  // 헤드 모듈의 국소 X축 (build_robot_v2.py FACES 의 xDir 과 동일 → 레일 방향이 CAD 조립과 같다)
  const HEAD_X = [[0, 0, -1], [0, -1, 0], [-1, 0, 0], [0, 0, -1], [0, -1, 0], [-1, 0, 0]];
  const COLORS = [0xf2f2f2, 0xd62828, 0x1b9e3f, 0xf7d308, 0xf77f00, 0x0057b8];
  const v3 = (a) => new THREE.Vector3(a[0], a[1], a[2]);

  // ----- 출력 큐브: 조각 18.8 mm, 피치 19.1 mm (간극 0.3 mm). 엣지의 노출면 2곳에 Ø3.4 구동 소켓, 센터에 M3 포켓 -----
  const cubeGroup = new THREE.Group(); scene.add(cubeGroup);
  const GEO = {};
  function geometryOf(key) { return GEO[key] || (GEO[key] = stlGeometry(MODELS.parts[key].b64,[0,0,0])); }
  const cubeBodies = [];
  const coreGroup = new THREE.Group(); scene.add(coreGroup);
  const cubies = {};  // "x,y,z" → Group
  const cubieGeo = new THREE.BoxGeometry(mm(P.piece_mm), mm(P.piece_mm), mm(P.piece_mm));
  const cubieMat = new THREE.MeshStandardMaterial({ color: 0x15181c, roughness: 0.6 });
  for (let x = -1; x <= 1; x++) for (let y = -1; y <= 1; y++) for (let z = -1; z <= 1; z++) {
    if (!x && !y && !z) continue;
    const g = new THREE.Group(); g.position.set(x, y, z);
    const source = (MODELS.cube || []).find((c) => c.pos[0] === x && c.pos[1] === y && c.pos[2] === z);
    const body = new THREE.Mesh(source ? geometryOf(source.key) : cubieGeo, cubieMat);
    g.add(body); cubeBodies.push(body);
    g.userData.home = [x, y, z];
    cubeGroup.add(g); cubies[`${x},${y},${z}`] = g;
  }
  for (const source of (MODELS.cube || []).filter((c) => c.pos.every((v) => v === 0))) {
    coreGroup.add(new THREE.Mesh(geometryOf(source.key),
      new THREE.MeshStandardMaterial({ color: 0xd7b26b, roughness: 0.5 })));
  }
  function centerSticker() {
    const shape = new THREE.Shape(), a = mm(7.75);
    shape.moveTo(-a,-a); shape.lineTo(a,-a); shape.lineTo(a,a); shape.lineTo(-a,a); shape.closePath();
    const hole = new THREE.Path(); hole.absarc(0,0,mm(3.6),0,Math.PI*2,true); shape.holes.push(hole);
    return new THREE.ShapeGeometry(shape);
  }
  const centerStickerGeo = centerSticker();
  const stickerGeo = new THREE.PlaneGeometry(mm(15.5), mm(15.5));
  const socketMat = new THREE.MeshStandardMaterial({ color: 0x0b0d10, roughness: 0.9 });
  const pocketMat = new THREE.MeshStandardMaterial({ color: 0x2b3038, roughness: 0.8 });
  const screwMat = new THREE.MeshStandardMaterial({ color: 0x9aa0a8, roughness: 0.4, metalness: 0.6 });
  const socketGeo = new THREE.CircleGeometry(mm(P.socket_mm / 2), 20);
  const socketWallGeo = new THREE.CylinderGeometry(mm(P.socket_mm / 2), mm(P.socket_mm / 2), mm(P.socket_depth_mm), 20, 1, true);
  const pocketGeo = new THREE.CircleGeometry(mm(3.5), 24);
  const screwGeo = new THREE.CircleGeometry(mm(2.7), 20);
  const stickers = [];  // 54개, 큐비의 자식
  for (let f = 0; f < 6; f++) for (let k = 0; k < 9; k++) {
    const r = (k / 3) | 0, c = k % 3;
    const pos = v3(N[f]).add(v3(RIGHT[f]).multiplyScalar(c - 1)).add(v3(DOWN[f]).multiplyScalar(r - 1));
    const owner = cubies[`${pos.x},${pos.y},${pos.z}`];
    const n = v3(N[f]);
    const isAxleCenter = k === 4 && (f === 2 || f === 5);
    const m = new THREE.Mesh(isAxleCenter ? centerStickerGeo : stickerGeo, new THREE.MeshStandardMaterial({ color: COLORS[f], roughness: 0.35 }));
    m.position.copy(n.clone().multiplyScalar(SURF + mm(0.05)));
    m.lookAt(n.clone().multiplyScalar(4));
    owner.add(m); stickers.push(m);
    const zeros = pos.toArray().filter((v) => v === 0).length;
    if (zeros === 1) {  // 엣지: 노출면 중앙에 구동 소켓 (Ø3.4, 깊이 4.2)
      const hole = new THREE.Mesh(socketGeo, socketMat);
      hole.position.copy(n.clone().multiplyScalar(SURF + mm(0.1))); hole.lookAt(n.clone().multiplyScalar(4)); owner.add(hole);
      const wall = new THREE.Mesh(socketWallGeo, new THREE.MeshStandardMaterial({ color: 0x1a1d22, side: THREE.BackSide }));
      wall.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), n);
      wall.position.copy(n.clone().multiplyScalar(SURF - mm(P.socket_depth_mm / 2))); owner.add(wall);
    } else if (zeros === 2 && !isAxleCenter) {  // 센터: Ø7 포켓 + M3 나사 머리
      const pocket = new THREE.Mesh(pocketGeo, pocketMat);
      pocket.position.copy(n.clone().multiplyScalar(SURF + mm(0.1))); pocket.lookAt(n.clone().multiplyScalar(4)); owner.add(pocket);
      const head = new THREE.Mesh(screwGeo, screwMat);
      head.position.copy(n.clone().multiplyScalar(SURF - mm(0.6))); head.lookAt(n.clone().multiplyScalar(4)); owner.add(head);
    }
  }
  function paint(cube) {
    const fc = cube.toFacelets();
    for (let i = 0; i < 54; i++) stickers[i].material.color.setHex(COLORS[fc[i]]);
  }

  // ----- STL (mm, base64) → BufferGeometry (단위: 피치). XY 중심·바닥 z=0 으로 저장된 출력 파일이므로 조립 오프셋을 더해 놓는다 -----
  function stlGeometry(b64, offset) {
    const bin = atob(b64), u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    const dv = new DataView(u8.buffer);
    const tri = dv.getUint32(80, true);
    const pos = new Float32Array(tri * 9), nor = new Float32Array(tri * 9);
    let o = 84;
    for (let t = 0; t < tri; t++) {
      const nx = dv.getFloat32(o, true), ny = dv.getFloat32(o + 4, true), nz = dv.getFloat32(o + 8, true); o += 12;
      for (let v = 0; v < 3; v++) {
        const i = t * 9 + v * 3;
        pos[i] = mm(dv.getFloat32(o, true) + offset[0]); pos[i + 1] = mm(dv.getFloat32(o + 4, true) + offset[1]); pos[i + 2] = mm(dv.getFloat32(o + 8, true) + offset[2]); o += 12;
        nor[i] = nx; nor[i + 1] = ny; nor[i + 2] = nz;
      }
      o += 2;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
    return g;
  }
  // V3 meshes already retain their CAD assembly coordinates in millimeters.
  for (const key of Object.keys(MODELS.parts || {})) geometryOf(key);
  const materials = new Map();
  function meshOf(key, color) {
    if (!GEO[key]) throw new Error('Missing V3 assembly mesh: ' + key);
    if (!materials.has(color)) materials.set(color, new THREE.MeshStandardMaterial({color, roughness:.5, metalness:.35}));
    return new THREE.Mesh(GEO[key], materials.get(color));
  }
  const outerGroup = new THREE.Group(), fixedAxleGroup = new THREE.Group();
  scene.add(outerGroup, fixedAxleGroup);
  for (const item of MODELS.frame || []) {
    const target = item.group === 'axle' ? fixedAxleGroup : outerGroup;
    target.add(meshOf(item.key, item.color));
  }
  const heads = [];
  for (let f = 0; f < 6; f++) {
    const n=v3(N[f]), x=v3(HEAD_X[f]), y=n.clone().cross(x);
    const face=new THREE.Group();
    face.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(x,y,n));
    face.position.copy(n.clone().multiplyScalar(HALF)); scene.add(face);
    const frame=new THREE.Group(), carriage=new THREE.Group(), structure=new THREE.Group();
    const motor=new THREE.Group(), spin=new THREE.Group(), motorSpin=new THREE.Group();
    face.add(frame,carriage); carriage.add(structure,motor,spin,motorSpin);
    const kind = f === 2 || f === 5 ? 'hollow' : 'direct';
    if (kind === 'hollow') motorSpin.position.x=mm(60);
    const groups={frame,carriage:structure,motor,spin,motorSpin};
    for (const item of MODELS.modules[kind]) groups[item.group].add(meshOf(item.key,item.color));
    const lockedPin=meshOf(MODELS.pins[kind].locked,0xff795b);
    const parkedPin=meshOf(MODELS.pins[kind].park,0x6db5cf);
    carriage.add(lockedPin,parkedPin);
    // Rotation witnesses make the 1:1 belt drive visible without spinning its body.
    const witnessGeo=new THREE.BoxGeometry(mm(2),mm(9),mm(.7));
    for (const g of kind==='hollow' ? [spin,motorSpin] : []) {
      const witness=new THREE.Mesh(witnessGeo,new THREE.MeshBasicMaterial({color:0xfff0c1}));
      witness.position.set(0,mm(7),mm(94.4));g.add(witness);
    }
    heads.push({face,frame,carriage,structure,motor,spin,motorSpin,lockedPin,parkedPin,kind,locked:false,retract:0,angle:0});
  }
  function setRetract(f,d) {heads[f].retract=d;heads[f].carriage.position.z=mm(d);}
  function setLock(f,locked) {
    const h=heads[f];h.locked=locked;h.lockedPin.visible=locked;h.parkedPin.visible=!locked;
  }

  // ---------- 카메라 조작 ----------
  const VIEW_ALL = { theta: 0.7, phi: 1.05, dist: 68 }, VIEW_CUBE = { theta: 0.7, phi: 1.0, dist: 15 };
  let theta = VIEW_ALL.theta, phi = VIEW_ALL.phi, dist = VIEW_ALL.dist;
  function updateCamera() {
    camera.position.set(dist * Math.sin(phi) * Math.sin(theta), dist * Math.cos(phi), dist * Math.sin(phi) * Math.cos(theta));
    camera.lookAt(0, 0, 0);
  }
  function setView(v) { theta = v.theta; phi = v.phi; dist = v.dist; updateCamera(); }
  let drag = null;
  canvas.addEventListener('pointerdown', (e) => { drag = { x: e.clientX, y: e.clientY }; canvas.style.cursor = 'grabbing'; });
  window.addEventListener('pointerup', () => { drag = null; canvas.style.cursor = 'grab'; });
  window.addEventListener('pointermove', (e) => {
    if (!drag) return;
    theta -= (e.clientX - drag.x) * 0.008; phi = Math.min(2.9, Math.max(0.25, phi - (e.clientY - drag.y) * 0.008));
    drag = { x: e.clientX, y: e.clientY }; updateCamera();
  });
  canvas.addEventListener('wheel', (e) => { e.preventDefault(); dist = Math.min(90, Math.max(4, dist * (e.deltaY > 0 ? 1.08 : 0.92))); updateCamera(); }, { passive: false });
  function resize() {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);

  // ---------- 동작 큐: 회전(move) 과 헤드 이송(feed) ----------
  const cube = new C.Cube();
  const pivot = new THREE.Group(); scene.add(pivot);
  const queue = [];       // 대기 중인 회전 {m, label}
  let current = null;     // 진행 중 동작: {type:'move', ...} | {type:'feed', ...}
  let paused = false;
  let allMoves = [], moveIdx = 0, queueLabel = '', onQueueDone = null, execStart = 0;
  let gripAxis = 2;       // 결합된 축 0=U/D 1=R/L 2=F/B. CAD 조립(robot_assembly.step)과 같이 F/B 결합에서 시작
  let regrips = 0;        // 이번 수열에서의 축 전환 횟수
  const speedEl = document.getElementById('speed'), feedEl = document.getElementById('feed');
  for (let f = 0; f < 6; f++) {
    setRetract(f, f % 3 === gripAxis ? 0 : P.retract_mm);
    setLock(f, f % 3 === gripAxis);
  }

  function startFeed(faces, from, to, then) {
    for (const f of faces) setLock(f,false);
    current = { type: 'feed', faces, from, to, then, start: performance.now(), dur: +feedEl.value };
    renderHeads(faces);
  }
  function startMove(item) {
    const f = (item.m / 3) | 0, k = item.m % 3;
    const opposite=(f+3)%6;
    setLock(opposite,true); setLock(f,false);
    if (heads[f].retract !== 0 || heads[opposite].retract !== 0 || !heads[opposite].locked ||
        heads.some((h,i) => i%3 !== f%3 && h.retract < P.retract_mm)) throw new Error('V3 grip/lock interlock failed');
    const turns = k === 2 ? -1 : k + 1;   // U=+1(시계 90°), U2=+2, U'=-1(반시계 90°, 모터도 반대로 50스텝)
    const n = v3(N[f]);
    const members = [];
    for (const g of Object.values(cubies)) {
      const h = g.userData.home;
      if (h[0] * n.x + h[1] * n.y + h[2] * n.z === 1) members.push(g);
    }
    pivot.rotation.set(0, 0, 0); pivot.updateMatrixWorld();
    for (const o of members) pivot.attach(o);
    current = { type: 'move', ...item, f, start: performance.now(), dur: Math.abs(turns) * +speedEl.value, members, axis: n, angle: -turns * Math.PI / 2 };
    renderQueue(); renderHeads();
  }
  // 다음 동작 선택: 다음 회전의 축이 결합 축과 다르면 [새 축 결합 → 기존 축 해제] 를 먼저 끼워 넣는다
  function startNext() {
    const item = queue[0];
    const axis = ((item.m / 3) | 0) % 3;
    if (axis !== gripAxis) {
      const incoming = [axis, axis + 3], outgoing = [gripAxis, gripAxis + 3];
      if (heads[axis].retract > 0) return startFeed(incoming, P.retract_mm, 0, null);
      return startFeed(outgoing, 0, P.retract_mm, () => { gripAxis = axis; regrips++; });
    }
    queue.shift(); startMove(item);
  }
  function finishMove() {
    pivot.setRotationFromAxisAngle(current.axis, current.angle);
    pivot.updateMatrixWorld();
    for (const o of current.members) {
      cubeGroup.attach(o); o.position.set(...o.userData.home); o.rotation.set(0, 0, 0);
    }
    const h = heads[current.f]; h.angle += current.angle; h.spin.rotation.z = h.angle; h.motorSpin.rotation.z = h.angle;   // 누적 각도 유지 (허브 세트스크류 보스가 90° 대칭이 아니라 되돌리면 튄다)
    cube.move(current.m); paint(cube);
    moveIdx++;
    if (moveIdx % 4 === 0 || moveIdx === allMoves.length) lcd(queueLabel, `${moveIdx}/${allMoves.length}`);
    current = null;
    renderQueue(); renderHeads();
    if (!queue.length && onQueueDone) { const cb = onQueueDone; onQueueDone = null; cb(); }
  }
  function finishFeed() {
    for (const f of current.faces) { setRetract(f, current.to); setLock(f,current.to===0); }
    const then = current.then; current = null;
    if (then) then();
    renderHeads();
  }
  function enqueue(moves, label, done) {
    allMoves = moves.slice(); moveIdx = 0; queueLabel = label; onQueueDone = done; execStart = performance.now(); regrips = 0;
    for (const m of moves) queue.push({ m, label });
    lcd(label, `0/${moves.length}`); renderQueue(); renderHeads();
    setBusy(true);
  }
  function animate(now) {
    requestAnimationFrame(animate);
    if (!current && queue.length && !paused) startNext();
    if (current && !paused) {  // 일시정지 중에는 start 를 건드리지 않는다 (재개 시 버튼 핸들러가 보정)
      const t = current.dur > 0 ? Math.min(1, (now - current.start) / current.dur) : 1;
      const ease = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      if (current.type === 'move') {
        pivot.setRotationFromAxisAngle(current.axis, current.angle * ease);
        heads[current.f].spin.rotation.z = heads[current.f].angle + current.angle * ease;
        heads[current.f].motorSpin.rotation.z = heads[current.f].spin.rotation.z;   // 헤드 국소 z = 면 법선 → 층과 같은 각도
        if (t >= 1) finishMove();
      } else {
        const d = current.from + (current.to - current.from) * ease;
        for (const f of current.faces) heads[f].carriage.position.z = mm(d);
        if (t >= 1) finishFeed();
      }
    }
    renderer.render(scene, camera);
  }

  // ---------- 패널 ----------
  const logEl = document.getElementById('log');
  function log(s) { logEl.textContent += s + '\n'; logEl.scrollTop = logEl.scrollHeight; }
  function lcd(a, b) {
    const pad = (s) => (s || '').toString().slice(0, 16).padEnd(16);
    document.getElementById('lcd').textContent = pad(a) + '\n' + pad(b);
  }
  function renderQueue() {
    const el = document.getElementById('queue');
    if (!allMoves.length) { el.textContent = ''; return; }
    el.innerHTML = allMoves.map((m, i) => `<span class="${i < moveIdx ? 'done' : i === moveIdx ? 'cur' : ''}">${C.moveName(m)}</span>`).join(' ');
  }
  // 헤드 상태 칩 6개 + 요약 문장. moving = 지금 이송 중인 면
  function renderHeads(moving = []) {
    const chips = document.getElementById('heads');
    chips.innerHTML = FACE_NAMES.map((name, f) => {
      const turning = current && current.type === 'move' && current.f === f;
      const cls = turning ? 'turn' : moving.includes(f) ? 'feed' : heads[f].locked ? 'locked' : heads[f].retract === 0 ? 'in' : 'out';
      return `<span class="chip ${cls}" data-face="${name}" data-locked="${heads[f].locked}" data-retract="${heads[f].retract}" title="${name}: ${heads[f].retract === 0 ? '핀 삽입 3 mm' : `후퇴 ${heads[f].retract} mm`}">${name}<small>${turning ? '회전' : moving.includes(f) ? '이송' : heads[f].locked ? '잠금' : heads[f].retract === 0 ? '결합' : `−${heads[f].retract}`}</small></span>`;
    }).join('');
    let text;
    if (current && current.type === 'feed') text = `축 전환: ${AXIS_NAMES[current.faces[0] % 3]} ${current.to === 0 ? '결합 중 (핀 삽입)' : '해제 중 (24 mm 후퇴)'}`;
    else if (current && current.type === 'move') text = `${FACE_NAMES[current.f]} 회전 — ${FACE_NAMES[(current.f+3)%6]} 잠금 · 나머지 네 헤드 후퇴 · 코어 고정`;
    else text = `${AXIS_NAMES[gripAxis]} 결합 대기`;
    document.getElementById('headText').textContent = `${text} · 축 전환 ${regrips}회 · 중앙축 0° 고정`;
  }
  function setBusy(b) { for (const id of ['btnScramble', 'btnSolve', 'btnMoves', 'btnReset']) document.getElementById(id).disabled = b; }
  const busy = () => !!current || queue.length > 0;
  // 수열의 축 전환 횟수(결합 축 기준, 시작 축 from)
  function countRegrips(moves, from) {
    let axis = from, n = 0;
    for (const m of moves) { const a = ((m / 3) | 0) % 3; if (a !== axis) { axis = a; n++; } }
    return n;
  }

  function doScramble(seed) {
    const seq = C.scramble(seed, SCRAMBLE_LEN);
    log(`SCRAMBLE seed=${seed} (${SCRAMBLE_LEN}): ${C.seqToString(seq)}`);
    enqueue(seq, 'SCRAMBLING', () => {
      log(`SCRAMBLED exec=${Math.round(performance.now() - execStart)}ms`);
      lcd('SCRAMBLED 20mv', `seed ${seed}`); setBusy(false);
    });
  }
  function doSolve() {
    if (cube.isSolved()) { log('ALREADY SOLVED'); lcd('ALREADY SOLVED', ''); return; }
    log('SOLVING'); lcd('SOLVING...', 'cross');
    const solver = new S.Solver();
    const t0 = performance.now();
    let r;
    try { r = solver.solve(cube); } catch (e) { log('SOLVE FAILED ' + e.message); lcd('SOLVE FAILED', 'check cube'); return; }
    const calcMs = performance.now() - t0;
    const tb = document.querySelector('#stages tbody'); tb.innerHTML = '';
    for (const st of r.stages) {
      log(`${st.name} (${st.moves.length}): ${C.seqToString(st.moves)} | nodes=${st.nodes} ms=${st.ms.toFixed(1)}`);
      const est = st.nodes / AVR_NODES_PER_SEC;
      tb.insertAdjacentHTML('beforeend', `<tr><td>${st.name}</td><td class="num">${st.moves.length}</td><td class="mv">${C.seqToString(st.moves)}</td><td class="num">${st.nodes}</td><td class="num">${est < 0.05 ? '<0.1' : est.toFixed(1)} s</td></tr>`);
    }
    log(`TOTAL ${r.moves.length}: ${C.seqToString(r.moves)}`);
    log(`CALC nodes=${r.nodes} ms=${calcMs.toFixed(1)}`);
    const nRegrip = countRegrips(r.moves, gripAxis);
    const quarterTurns = r.moves.reduce((s, m) => s + (m % 3 === 1 ? 2 : 1), 0);
    document.getElementById('stMoves').textContent = r.moves.length;
    document.getElementById('stNodes').textContent = r.nodes.toLocaleString();
    document.getElementById('stTime').textContent = calcMs.toFixed(1);
    document.getElementById('stRegrip').textContent = nRegrip;
    document.getElementById('estNote').textContent = `Uno 예상 = 노드 ÷ ${Math.round(AVR_NODES_PER_SEC).toLocaleString()} 노드/초 (Wokwi 시드 1 실측). 전체 ${(r.nodes / AVR_NODES_PER_SEC).toFixed(1)} s. UNO R4(48 MHz, 32bit)는 이보다 수 배 빠를 것으로 예상(실측 전). `
      + `기구 실행 예상 = 90° ${quarterTurns}회 × ${speedEl.value} ms + 축 전환 ${nRegrip}회 × 2 × ${feedEl.value} ms ≈ ${((quarterTurns * +speedEl.value + nRegrip * 2 * +feedEl.value) / 1000).toFixed(1)} s (이송은 자동화 목표값, 실물은 수동 이송·잠금, 화면 시간은 동작 설명용).`;
    enqueue(r.moves, 'EXECUTING', () => {
      const ok = cube.isSolved();
      log(`SOLVED ok=${ok ? 1 : 0} moves=${r.moves.length} calc=${Math.round(calcMs)}ms exec=${Math.round(performance.now() - execStart)}ms`);
      lcd(ok ? 'SOLVED!' : 'MISMATCH', `${r.moves.length}mv`); setBusy(false);
    });
  }
  function doMoves(str) {
    let seq;
    try { seq = C.parseMoves(str); } catch (e) { log('ERR bad moves'); return; }
    if (!seq.length) return;
    enqueue(seq, 'MOVING', () => { log(`MOVED ${seq.length}`); lcd('CUBE ROBOT', cube.isSolved() ? 'solved' : 'scrambled'); setBusy(false); });
  }

  document.getElementById('btnScramble').onclick = () => { if (!busy()) doScramble(parseInt(document.getElementById('seed').value, 10) || 0); };
  document.getElementById('btnSolve').onclick = () => { if (!busy()) doSolve(); };
  document.getElementById('btnMoves').onclick = () => { if (!busy()) doMoves(document.getElementById('moves').value); };
  document.getElementById('moves').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !busy()) doMoves(e.target.value); });
  document.getElementById('btnReset').onclick = () => { if (busy()) return; cube.reset(); paint(cube); log('RESET'); lcd('CUBE ROBOT', 'reset'); allMoves = []; renderQueue(); };
  document.getElementById('btnPause').onclick = (e) => {
    paused = !paused; e.target.textContent = paused ? '계속' : '일시정지';
    if (current) {
      if (paused) current.elapsed = performance.now() - current.start;
      else current.start = performance.now() - (current.elapsed || 0);  // 숨김 탭 등으로 rAF 가 멈췄어도 이어서 진행
    }
    if (paused) lcd('PAUSED', `${moveIdx}/${allMoves.length}`); else if (allMoves.length) lcd(queueLabel, `${moveIdx}/${allMoves.length}`);
  };
  document.getElementById('btnView').onclick = () => setView(VIEW_ALL);
  document.getElementById('btnViewCube').onclick = () => setView(VIEW_CUBE);
  speedEl.oninput = () => { document.getElementById('speedVal').textContent = speedEl.value; };
  feedEl.oninput = () => { document.getElementById('feedVal').textContent = feedEl.value; };
  const chkFrame=document.getElementById('chkFrame'), chkMotor=document.getElementById('chkMotor');
  const chkOuter=document.getElementById('chkOuter'), chkAxle=document.getElementById('chkAxle'), chkInside=document.getElementById('chkInside');
  function applyVisibility() {
    outerGroup.visible=chkOuter.checked; fixedAxleGroup.visible=coreGroup.visible=chkAxle.checked;
    for (const h of heads) {
      h.frame.visible=h.structure.visible=chkFrame.checked;
      h.motor.visible=chkMotor.checked;
    }
    const inside=chkInside.checked;
    cubieMat.transparent=inside; cubieMat.opacity=inside?.12:1; cubieMat.depthWrite=!inside;
    for (const m of stickers) {m.material.transparent=inside;m.material.opacity=inside?.16:1;m.material.depthWrite=!inside;}
  }
  for (const chk of [chkFrame,chkMotor,chkOuter,chkAxle,chkInside]) chk.onchange=applyVisibility;

  // 시작
  paint(cube); resize(); updateCamera(); applyVisibility(); renderHeads();
  log('READY V3 · 고정 중앙축 / 반대 면 잠금 / F-B 중공 벨트 / 개방 프레임');
  requestAnimationFrame(animate);
  window.CubeSim = { cube, doScramble, doSolve, doMoves, heads: () => ({ gripAxis, regrips, retract: heads.map((h) => h.retract), locked:heads.map(h=>h.locked), angles:heads.map(h=>h.angle), coreFixed:true, outerPanels:0 }), params: P };  // 콘솔/테스트용
})();
