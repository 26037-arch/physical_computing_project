큐브 로봇 V2 CAD 시제품

1. 이 ZIP을 한 폴더에 압축 해제합니다.
2. docs/HARDWARE_V2.md에서 구조와 검증 범위를 확인합니다.
3. models/robot_v2/cube 및 head 폴더에 출력 STL이 있습니다.
4. Fusion 360에서 FusionMCPBridge 애드인을 실행합니다.
5. 이 폴더의 터미널에서 다음 명령을 실행합니다(Node.js 필요).

node tools/fusion-bridge/import-robot-v2.mjs cube
node tools/fusion-bridge/import-robot-v2.mjs head
node tools/fusion-bridge/import-robot-v2.mjs robot

각 명령은 새 Fusion 문서에 STEP를 가져와 F3D와 화면 PNG를 저장합니다.
현재 산출물은 CadQuery에서 생성한 STEP/STL이며 Fusion 실행과 실제 출력은 미검증입니다.
후퇴는 수동 M5 이송 방식입니다. 자동 후퇴 구동기와 외부 프레임은 별도 구현 대상입니다.
공차 시험편과 손으로 회전하는 큐브를 먼저 시험한 뒤 모터를 결합합니다.
